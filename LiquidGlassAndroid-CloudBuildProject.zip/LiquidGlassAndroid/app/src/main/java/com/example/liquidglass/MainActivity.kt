package com.example.liquidglass

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LiquidGlassApp() }
    }
}

@Composable
fun LiquidGlassApp() {
    val context = LocalContext.current
    var wallpaper by remember { mutableStateOf<ImageBitmap?>(null) }
    var blurLook by remember { mutableFloatStateOf(0.55f) }
    var opacity by remember { mutableFloatStateOf(0.30f) }
    var shine by remember { mutableFloatStateOf(0.75f) }
    var stretch by remember { mutableFloatStateOf(0.75f) }
    var tint by remember { mutableFloatStateOf(0.48f) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)?.asImageBitmap()
                }
            }.getOrNull()?.let { wallpaper = it }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(Color(0xFF10131D))) {
            GlassBackdrop(wallpaper, tint)
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("LIQUID GLASS", color = Color.White, fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                        Text("Play with light.", color = Color.White.copy(.72f), fontSize = 14.sp)
                    }
                    IconButton(onClick = {
                        blurLook = .55f; opacity = .30f; shine = .75f; stretch = .75f; tint = .48f
                    }) { Icon(Icons.Default.Refresh, "Reset", tint = Color.White) }
                }

                Spacer(Modifier.height(28.dp))
                Text("INTERACTIVE PREVIEW", color = Color.White.copy(.65f), fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(14.dp))
                GlassDemoCard(blurLook, opacity, shine, stretch)
                Spacer(Modifier.height(12.dp))
                Text("Drag the glass surface. It stretches and springs back.", color = Color.White.copy(.72f), fontSize = 12.sp)
                Spacer(Modifier.height(26.dp))

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("CUSTOMIZE", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { picker.launch("image/*") }) {
                        Icon(Icons.Default.Image, null, tint = Color.White)
                        Spacer(Modifier.width(6.dp))
                        Text("Change background", color = Color.White)
                    }
                }
                GlassSlider("Glass transparency", opacity, { opacity = it }, "Less", "More")
                GlassSlider("Frosted blur look", blurLook, { blurLook = it }, "Clear", "Frosted")
                GlassSlider("Light & highlights", shine, { shine = it }, "Soft", "Glossy")
                GlassSlider("Stretch intensity", stretch, { stretch = it }, "Subtle", "Elastic")
                GlassSlider("Background tint", tint, { tint = it }, "Natural", "Colorful")
                Spacer(Modifier.height(24.dp))
                Text("Made for Android • Standalone preview", color = Color.White.copy(.45f), fontSize = 11.sp)
                Spacer(Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun GlassBackdrop(bitmap: ImageBitmap?, tint: Float) {
    Canvas(Modifier.fillMaxSize()) {
        if (bitmap != null) {
            val scale = maxOf(size.width / bitmap.width, size.height / bitmap.height)
            val w = bitmap.width * scale
            val h = bitmap.height * scale
            drawImage(bitmap, dstOffset = IntOffsetCompat(((size.width-w)/2).toInt(), ((size.height-h)/2).toInt()),
                dstSize = IntSizeCompat(w.toInt(), h.toInt()))
            drawRect(Color(0xFF10131D).copy(alpha = .20f))
        } else {
            drawRect(brush = Brush.linearGradient(
                listOf(Color(0xFF182B55), Color(0xFF543A75), Color(0xFFB66B91), Color(0xFF172C4C)),
                start = Offset.Zero, end = Offset(size.width, size.height)
            ))
            drawCircle(Color(0xFF77C9E8).copy(.30f), size.minDimension * .32f, Offset(size.width*.18f, size.height*.22f))
            drawCircle(Color(0xFFEBA4D1).copy(.28f), size.minDimension * .38f, Offset(size.width*.85f, size.height*.58f))
            drawCircle(Color(0xFF8D9DFF).copy(.22f), size.minDimension * .30f, Offset(size.width*.30f, size.height*.82f))
        }
        drawRect(Color(0xFF18223B).copy(alpha = tint * .30f))
    }
}

// Small aliases keep the drawImage destination explicit and compatible with Compose versions.
private fun IntOffsetCompat(x: Int, y: Int) = androidx.compose.ui.unit.IntOffset(x, y)
private fun IntSizeCompat(w: Int, h: Int) = androidx.compose.ui.unit.IntSize(w, h)

@Composable
private fun GlassDemoCard(blur: Float, opacity: Float, shine: Float, stretch: Float) {
    val dragX = remember { Animatable(0f) }
    val dragY = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var dragging by remember { mutableStateOf(false) }

    BoxWithConstraints(Modifier.fillMaxWidth().height(236.dp), contentAlignment = Alignment.Center) {
        val maxDrag = 74f * stretch
        val dx = dragX.value.coerceIn(-maxDrag, maxDrag)
        val dy = dragY.value.coerceIn(-maxDrag, maxDrag)
        val shape = RoundedCornerShape(34.dp)
        Box(
            Modifier
                .offset(x = (dx * .35f).dp, y = (dy * .35f).dp)
                .width(270.dp)
                .height(174.dp)
                .graphicsLayer {
                    val pull = (abs(dx) + abs(dy)) / 150f
                    scaleX = 1f + pull * .20f
                    scaleY = 1f + pull * .07f
                    rotationZ = dx * .035f
                }
                .clip(shape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = opacity + shine*.22f),
                            Color(0xFFDAE9FF).copy(alpha = opacity*.55f),
                            Color.White.copy(alpha = opacity*.16f)
                        )
                    )
                )
                .pointerInput(stretch) {
                    detectDragGestures(
                        onDragStart = { dragging = true },
                        onDragEnd = {
                            dragging = false
                            scope.launch { dragX.animateTo(0f, spring(dampingRatio=.38f, stiffness=240f)) }
                            scope.launch { dragY.animateTo(0f, spring(dampingRatio=.38f, stiffness=240f)) }
                        },
                        onDragCancel = {
                            dragging = false
                            scope.launch { dragX.animateTo(0f, spring()) }
                            scope.launch { dragY.animateTo(0f, spring()) }
                        },
                        onDrag = { change, amount ->
                            change.consume()
                            scope.launch {
                                dragX.snapTo((dragX.value + amount.x * stretch).coerceIn(-maxDrag, maxDrag))
                                dragY.snapTo((dragY.value + amount.y * stretch).coerceIn(-maxDrag, maxDrag))
                            }
                        }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                // Inner edge and top specular highlight.
                drawRoundRect(
                    Brush.linearGradient(
                        listOf(Color.White.copy(shine*.72f), Color.White.copy(.06f), Color.White.copy(shine*.30f)),
                        start = Offset.Zero, end = Offset(size.width, size.height)
                    ),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.3.dp.toPx()),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(34.dp.toPx())
                )
                drawRoundRect(
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = shine*.34f), Color.Transparent, Color.White.copy(alpha = shine*.08f)),
                        start = Offset(0f, 0f), end = Offset(size.width*.9f, size.height*.55f)
                    ),
                    topLeft = Offset(2.dp.toPx(), 2.dp.toPx()),
                    size = Size(size.width-4.dp.toPx(), size.height*.48f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(32.dp.toPx())
                )
                if (dragging) {
                    drawCircle(Color.White.copy(.20f), size.minDimension*.20f, Offset(size.width*.5f, size.height*.5f))
                }
            }
            Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(35.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(.20f)), contentAlignment = Alignment.Center) {
                        Text("◈", color = Color.White, fontSize = 21.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Liquid surface", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Dynamic glass material", color = Color.White.copy(.70f), fontSize = 10.sp)
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("DRAG ME", color = Color.White.copy(.82f), letterSpacing = 2.sp, fontSize = 10.sp)
                    Text("✦", color = Color.White.copy(.90f), fontSize = 22.sp)
                }
            }
        }
    }
}

@Composable
private fun GlassSlider(label: String, value: Float, onValue: (Float) -> Unit, low: String, high: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text("${(value*100).toInt()}%", color = Color.White.copy(.65f), fontSize = 11.sp)
        }
        Slider(value = value, onValueChange = onValue, modifier = Modifier.height(34.dp),
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.White.copy(.85f),
                inactiveTrackColor = Color.White.copy(.20f)
            )
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(low, color = Color.White.copy(.48f), fontSize = 10.sp)
            Text(high, color = Color.White.copy(.48f), fontSize = 10.sp)
        }
    }
}
