# Liquid Glass for Android

A standalone Android Studio project demonstrating a customizable, interactive Liquid Glass-inspired surface.

## Features
- Interactive glass card: drag it to see elastic scaling, tilt, and spring-back.
- Choose a wallpaper from the device gallery.
- Tune transparency, frosted-glass look, highlights, stretch intensity, and background tint.
- Reset controls to defaults.

## Build
1. Open this folder in Android Studio (a recent version).
2. Allow Gradle to sync and download the Android Gradle Plugin and AndroidX dependencies.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated debug APK on an Android device.

Minimum Android version: Android 8.0 (API 26).

## Notes
This is a standalone visual playground, not a system-wide overlay. Android does not expose iOS's private Liquid Glass rendering engine, so this project recreates the visual language with Compose drawing, gradients, translucent layers, and touch-driven spring animation. The "frosted blur look" slider currently controls the glass material's visual softness/opacity; true backdrop blur can be added in a later iteration.


## Build an APK in the cloud from your phone (GitHub Actions)

1. Create a GitHub account if you do not already have one.
2. In GitHub, create a **new repository** and upload the contents of this project ZIP (extract it first).
3. Open the repository's **Actions** tab. If prompted, allow GitHub Actions.
4. The workflow named **Build Liquid Glass APK** runs automatically after a push to `main`. You can also choose it under **Actions** and tap **Run workflow**.
5. When it finishes successfully, open the run, scroll to **Artifacts**, and download **LiquidGlass-debug-apk**.
6. Extract the artifact ZIP on your Android phone and install `app-debug.apk`. Android may ask you to allow installs from your browser or file manager.

The workflow compiles the debug APK on a GitHub-hosted Linux runner; Android Studio is not needed on your phone. GitHub account and Actions availability/usage limits apply.
